window.onload = ()=>{
    // $(selector).countMe(delay,speed)
    $("#num1").countMe(40,65);
    $("#num2").countMe(30, 30);
    $("#num3").countMe(40, 50);
    $("#num4").countMe(100,200);
 }